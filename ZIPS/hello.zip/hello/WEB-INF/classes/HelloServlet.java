import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Date;

import netscape.javascript.JSObject;

import java.awt.*;
import java.lang.reflect.Array;
import java.net.*;
import java.io.*;
import org.json.*;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.util.ArrayList;
import java.util.Scanner;
 
public class HelloServlet extends HttpServlet {
   PrintWriter out;
   @Override
   public void doGet(HttpServletRequest request, HttpServletResponse response)
         throws IOException, ServletException {
 
      // Set the response MIME type of the response message
      response.setContentType("text/html");
      // Allocate a output writer to write the response message into the network socket
      out = response.getWriter();
 
      // Write the response message, in an HTML page
      try {
         JSONObject object = jsonObjectMaker("https://anapioficeandfire.com/api/characters/583");
         JSONArray urlArray = object.getJSONArray("allegiances");

         //Set new url:
         String url2 = urlArray.get(0).toString();
         JSONObject object2 = jsonObjectMaker(url2);
         JSONArray urlArray2 = object2.getJSONArray("swornMembers");

         out.println("<html>");
         out.println("<head><title>Hello, this is "+ object.getString("name")+"</title></head>");
         out.println("<body>");
         out.println("<h1>"+object.getString("name")+"</h1>");
         out.println("<p>Name: " + object.getString("name")  + "</p>");
         out.println("<p>Gender: " + object.getString("gender")  + "</p>");
         out.println("<p>Born: " + object.getString("born")  + "</p>");
         out.println("<p>Culture: " + object.getString("culture")  + "</p>");

          out.println("<h1>Sworn Members of previous house:</h1>");

          //Iterate through each url and print names:
          for (int i = 0; i < urlArray2.length(); i++){
              JSONObject character = jsonObjectMaker(urlArray2.getString(i));
              out.println("<p>"+character.getString("name")+"</p>");
              Thread.sleep(100);
          }

         out.println("</body></html>");
      } catch(JSONException e){

      }catch(InterruptedException e){

      }
      finally {
         out.close();  // Always close the output writer
      }
   }
    //******************************************Makes JSON Object from string*******************************************
    public static JSONObject jsonObjectMaker(String url){
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        JSONObject object = null;
        try {
            URLConnection connection = new URL(url).openConnection();
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
            connection.connect();
            BufferedReader buffer = new BufferedReader(new InputStreamReader(connection.getInputStream()));

            while ((line = buffer.readLine()) != null) {
                stringBuilder.append(line);
            }
            object = new JSONObject(stringBuilder.toString());

        }catch (IOException e){
            System.out.println(e);
        }catch (JSONException e){
            System.out.println(e);
        }
        return object;
    }


}