public interface Payment {
    int calcAmount(int price,int paid);
}